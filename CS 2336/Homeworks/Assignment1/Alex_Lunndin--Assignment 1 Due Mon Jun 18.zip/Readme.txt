Alex Lundin
06-18-2017
Assignment 1

Readme File

Quadratic.java
	Sample 1
	22
	5
	17
	Sample 2
	0
	-31
	9
	
Payroll.java
	Sample 1
	John
	15
	22.50
	.33
	.1
	Sample 2
	Tamy
	20
	35
	.15
	.01
	Sample 3
	Sable
	40
	600 
	.37
	.2

Calendar.java
	Sample 1
	2000
	5
	Sample 2
	2500
	8
	Sample 3
	1992
	3