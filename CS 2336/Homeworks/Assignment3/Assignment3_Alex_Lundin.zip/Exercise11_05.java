//Alex Lundin
//07-09-2017
//Assignment 3


public class Exercise11_05 {


   public static void main(String[] args) {
      System.out.println ("" );
      System.out.println ("" );
      System.out.println ("" );
      System.out.println ("Welcome to Exercise11_05. " );
      System.out.println ("This program creates ArrayList and adds two students, Joe and Pete." );
      System.out.println ("Then the students names are printed." );
      
      Course myCourse = new Course ("CS2336");
      myCourse.addStudent("Joe");
      myCourse.addStudent("Pete");
      myCourse.printStudents();

   } 

}