Alex Lundin
07-10-2017
Assignment 3

Readme File

Complie and run:
Exercise11_02
Exercise11_03
Exercise11_05
Exercise11_06