Alex Lundin
06-25-2017
Assignment 2

Readme File

Ex07_31
	Sample 1
	4
	1
	7
	8
	9
	
	5
	2
	3
	8
	22
	51
	
	
	Sample 2
	3
	2
	55
    150
	
	4
	1
	8
	16
	32
	
Ex07_32
	Sample 1
	5
	15
	1
	2
	7
	0
	
	Sample 2
	4
	22
	30
	31
	15


Ex09_11
	Sample 1
	1.0
	2.0
	3.0
	4.0
	5.0
	6.0
	
	Sample 2
	5.0
	2.0
	7.0
	9.0
	8.0
	4.0