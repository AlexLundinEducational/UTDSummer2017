Readme

Video Verification
https://knowledge.autodesk.com/community/screencast/54008880-57d9-46c0-99be-3484e2fd0a09

Project Framework

If statments to parse messages on server
	try catch block to connect to url
		Store JSON object
			Parse the object based on what url was hit
			Send data back to main function
			Output data in server window
		